import requests
from bs4 import BeautifulSoup
import pandas as pd
import re
from urllib.parse import urljoin
import time

# Email regex
EMAIL_REGEX = r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+'

# Phone regex
PHONE_REGEX = r'(\+?\d[\d\-\(\) ]{8,}\d)'

# Contact keywords
CONTACT_KEYWORDS = [
    "contact",
    "contact-us",
    "contactus",
    "about",
    "support",
    "help"
]

headers = {
    "User-Agent": "Mozilla/5.0"
}


def find_contact_page(base_url):
    try:
        response = requests.get(base_url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.text, "html.parser")

        for link in soup.find_all("a", href=True):
            href = link['href'].lower()

            for keyword in CONTACT_KEYWORDS:
                if keyword in href:
                    return urljoin(base_url, link['href'])

        return base_url

    except:
        return base_url


def extract_data(url):
    try:
        response = requests.get(url, headers=headers, timeout=10)

        emails = re.findall(EMAIL_REGEX, response.text)
        phones = re.findall(PHONE_REGEX, response.text)

        return list(set(emails)), list(set(phones))

    except:
        return [], []


# Load Excel (NO HEADER DEPENDENCY)
df = pd.read_excel("websites.xlsx", header=None)

# First column as websites
websites = df.iloc[:, 0].dropna().tolist()

print(f"Total Websites Found: {len(websites)}")

results = []

for index, website in enumerate(websites):

    website = str(website).strip()

    if not website.startswith("http"):
        website = "https://" + website

    print(f"Processing {index+1} / {len(websites)} : {website}")

    contact_page = find_contact_page(website)
    emails, phones = extract_data(contact_page)

    results.append({
        "Website": website,
        "Contact Page": contact_page,
        "Emails": ", ".join(emails),
        "Phones": ", ".join(phones)
    })

    time.sleep(0.5)


# Save output
output = pd.DataFrame(results)
output.to_excel("contacts_output.xlsx", index=False)

print("Done ✅ contacts_output.xlsx created")