import smtplib
import time
import pandas as pd
from email.mime.text import MIMEText

EMAIL = "abhishekwebit@gmail.com"
PASSWORD = "nfns thav eshr ftdf"  # Use App Password if 2FA enabled

df = pd.read_csv("leads.csv")

def send_email(to_email, name):
    msg = MIMEText(f"Hey {name},\n\nQuick question — are you still manually handling leads?\n\nI can help automate it.")
    msg["Subject"] = "Quick question"
    msg["From"] = EMAIL
    msg["To"] = to_email

    try:
        server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
        server.login(EMAIL, PASSWORD)
        server.sendmail(EMAIL, to_email, msg.as_string())
        server.quit()
        print("Sent:", to_email)
    except:
        print("Failed:", to_email)

for index, row in df.iterrows():
    send_email(row["Email"], row["Name"])
    time.sleep(10)  # delay (IMPORTANT)